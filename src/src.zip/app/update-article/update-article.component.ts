import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-article',
  templateUrl: './update-article.component.html',
  styleUrls: ['./update-article.component.css']
})
export class UpdateArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
