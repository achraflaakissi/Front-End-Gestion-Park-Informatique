import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-article',
  templateUrl: './delete-article.component.html',
  styleUrls: ['./delete-article.component.css']
})
export class DeleteArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
